/**
 * index.js
 * ============================================================
 * Entry point utama Telegram Auto Order Bot.
 *
 * Urutan startup:
 * 1. Load & validasi konfigurasi (.env)
 * 2. Tes koneksi database PostgreSQL
 * 3. Jalankan migration database secara OTOMATIS (idempotent —
 *    aman dijalankan berulang, migration yang sudah ada di-skip)
 * 4. Buat instance bot Telegraf + registrasi command/handler
 * 5. Inisialisasi payment checker service dengan instance bot
 * 6. Resume polling untuk order PENDING yang sempat tertinggal
 * 7. Mulai expired sweeper job (cron 1 menit)
 * 8. Launch bot (long polling)
 * 9. Setup graceful shutdown
 *
 * Cara menjalankan:
 *   npm install
 *   npm start
 *
 * Catatan: migration TIDAK perlu dijalankan manual lagi.
 * Bot otomatis membuat tabel yang belum ada setiap kali start.
 * ============================================================
 */

'use strict';

const config = require('./src/config/config');
const logger = require('./src/utils/logger');
const { testConnection, pool } = require('./src/database/pool');
const { runMigrations } = require('./src/database/migrate');
const { startDashboardServer } = require('./src/server/dashboardServer');
const { autoSyncPremku } = require('./src/services/premkuAutoSyncService');
const { createBot } = require('./src/bot');
const paymentChecker = require('./src/services/paymentCheckerService');
const premkuPolling = require('./src/services/premkuPollingService');
const premiumFulfillment = require('./src/services/premiumFulfillmentService');

async function main() {
  logger.info('Startup', '======================================');
  logger.info('Startup', 'Telegram Auto Order Bot — Starting...');
  logger.info('Startup', '======================================');

  // ============================================================
  // 1. Tes koneksi database sebelum bot dijalankan
  // ============================================================
  const dbConnected = await testConnection();
  if (!dbConnected) {
    logger.error('Startup', 'Database tidak dapat dijangkau. Periksa DATABASE_URL di .env.');
    process.exit(1);
  }

  // ============================================================
  // 2. Jalankan migration otomatis (aman dipanggil berulang —
  //    migration yang sudah pernah jalan otomatis di-skip)
  // ============================================================
  try {
    const { executedCount, totalFiles } = await runMigrations();
  await autoSyncPremku();
    logger.success('Startup', `Migration selesai: ${executedCount}/${totalFiles} baru dijalankan.`);
  } catch (error) {
    logger.error('Startup', 'Migration gagal:', error.message);
    process.exit(1);
  }

  // ============================================================
  // 3. Buat instance bot dan registrasi semua command/handler
  // ============================================================
  const bot = createBot();

  // ============================================================
  // 4. Inisialisasi payment checker dengan instance bot
  //    (dibutuhkan untuk kirim notifikasi & hapus pesan)
  // ============================================================
  paymentChecker.init(bot);
  premkuPolling.init(bot);
  premiumFulfillment.init(bot);

  // ============================================================
  // 5. Resume polling untuk order PENDING yang tertinggal
  //    (misalnya bot baru saja restart)
  // ============================================================
  await paymentChecker.resumePendingOrders();
  await premkuPolling.resumePendingDeposits();

  // ============================================================
  // 6. Mulai sweeper job untuk auto-expire order yang terlewat
  // ============================================================
  paymentChecker.startExpiredSweeper();

  // ============================================================
  // 7. Graceful shutdown — tutup koneksi database & stop bot dengan rapi
  // ============================================================
  const shutdown = async (signal) => {
    logger.warn('Shutdown', `Menerima ${signal}. Menghentikan bot...`);
    bot.stop(signal);
    await pool.end();
    logger.info('Shutdown', 'Bot dan koneksi database ditutup dengan baik.');
    process.exit(0);
  };

  process.once('SIGINT', () => shutdown('SIGINT'));
  process.once('SIGTERM', () => shutdown('SIGTERM'));

  // ============================================================
  // 8. Launch bot (long polling ke Telegram API)
  // ============================================================
  logger.info('Startup', 'Menghubungkan ke Telegram API...');

  startDashboardServer();
  await bot.launch();

  logger.success('Startup', '======================================');
  logger.success('Startup', 'Bot berhasil dijalankan!');
  logger.info('Startup', `Admin terdaftar: ${config.adminIds.length} orang`);
  logger.info('Startup', `Interval cek pembayaran: ${config.payment.checkIntervalMs}ms`);
  logger.success('Startup', '======================================');
}

main().catch((error) => {
  logger.error('Startup', 'Gagal menjalankan aplikasi:', error.message);
  console.error(error.stack);

  if (error.message && error.message.includes('401')) {
    logger.error('Startup', 'BOT_TOKEN tidak valid. Periksa file .env.');
  }

  process.exit(1);
});
